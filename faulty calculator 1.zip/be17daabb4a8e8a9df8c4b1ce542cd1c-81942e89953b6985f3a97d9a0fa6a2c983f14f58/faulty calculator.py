#luffytaro
#anyone can use this code and make changes in code.

choice = 0
print("\n1.Add")
print("\n2.Minus")
print("\n3.Divide")
print("\n4.Multiply")
choice = int(input("Enter your choice ="))
n1 = int(input("Enter first number"))
n2 = int(input("Enter second number"))
if choice == 1:
    if n1 == 56 and n2 == 9:
        print(77)
    elif n1 == 9 and n2 == 56:
        print(77)
    else:
        print("sum =",n1+n2)
if choice == 2:
    print("minus =",n1-n2)
if choice == 3:
    if n1 == 56 and n2 ==7:
        print(4)
    else:
        print("Divide =",n1/n2)
if choice == 4:
    if n1 == 45 and n2 == 3:
        print(555)
    elif n1 == 3 and n2 == 45:
        print(555)
    else:
        print("Multiply =",n1*n2)